// src/app/cities/city.model.ts

export interface City {
    name: string;
    imageUrl: string;
    description: string;
    isPopular: boolean;
    price: string;     
    ratings: number;
    type: string;
  }
  