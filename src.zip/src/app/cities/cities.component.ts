import { Component, OnInit, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { City } from './cities.model'; // Import the City interface
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cities',
  standalone: true, // Ensure standalone is true
  imports: [CommonModule,FormsModule], // Import CommonModule here
  templateUrl: './cities.component.html',
  styleUrls: ['./cities.component.css']
})
export class CitiesComponent implements OnInit, OnChanges, OnDestroy {

  private _searchTerm: string = '';
  private _selectedType: string = 'All';
  filteredCities: City[] = [];

  cities: City[] = [
    {
      name: 'Paris',
      imageUrl: 'assets/images/paris.jpg',
      description: 'The capital of France, known for its art, fashion, and culture.',
      isPopular: true,
      price: '$2000',
      ratings: 4.5,
      type: 'Cultural/Heritage'
    },
    {
      name: 'New York',
      imageUrl: 'assets/images/newyork.jpg',
      description: 'The largest city in the USA, known for its skyscrapers and vibrant lifestyle.',
      isPopular: true,
      price: '$5000',
      ratings: 4.7,
      type: 'Family Travel'
    },
    {
      name: 'Tokyo',
      imageUrl: 'assets/images/japan.jpg',
      description: 'The bustling capital of Japan, famous for technology and food.',
      isPopular: true,
      price: '$1500',
      ratings: 4.0,
      type: 'Cultural/Heritage'
    },
    {
      name: 'Sydney',
      imageUrl: 'assets/images/sydney.jpg',
      description: 'The beautiful coastal city in Australia, known for the Sydney Opera House.',
      isPopular: true,
      price: '$1000',
      ratings: 3.9,
      type: 'Adventure/Hiking'
    },
    {
      name: 'London',
      imageUrl: 'assets/images/London.jpg',
      description: 'The capital of the United Kingdom, famous for its history and landmarks.',
      isPopular: true,
      price: '$2200',
      ratings: 4.7,
      type: 'Cultural/Heritage'
    },
    {
      name: 'Rome',
      imageUrl: 'assets/images/Rome.jpg',
      description: 'The capital of Italy, known for its ancient ruins and vibrant culture.',
      isPopular: true,
      price: '$2000',
      ratings: 4.3,
      type: 'Cultural/Heritage' 
    }
  ];

    // Use getter and setter for search term
    get searchTerm(): string {
      return this._searchTerm;
    }
  
    set searchTerm(value: string) {
      this._searchTerm = value;
      this.filterCities();
    }
  
    // Use getter and setter for selected destination type
    get selectedType(): string {
      return this._selectedType;
    }
  
    set selectedType(value: string) {
      this._selectedType = value;
      this.filterCities();
    }
  
    constructor() {
      console.log('CitiesComponent Constructor');
    }
  
    ngOnInit(): void {
      console.log('CitiesComponent Initialized');
      this.filterCities(); // Initialize with full list
    }
  
    ngOnChanges(changes: SimpleChanges): void {
      console.log('CitiesComponent Changes Detected:', changes);
    }
  
    ngOnDestroy(): void {
      console.log('CitiesComponent Destroyed');
    }
  
    // Filter cities based on search term and selected type
    filterCities = (): void => {
      this.filteredCities = this.cities
        .filter(city => city.name.toLowerCase().includes(this.searchTerm.toLowerCase()))
        .filter(city => this.selectedType === 'All' || city.type === this.selectedType);
    };

    // Selected city details for the pop-up
    selectedCity: any = null;

    // Method to open modal with the selected city data
    openCityModal(city: any) {
      this.selectedCity = city;
    }
  
    // Method to close the modal
    closeModal() {
      this.selectedCity = null;
    }
}
